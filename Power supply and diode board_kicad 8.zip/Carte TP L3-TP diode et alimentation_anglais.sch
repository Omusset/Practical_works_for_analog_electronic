EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 8268 11693 portrait
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L Connector_Generic:Conn_01x03 J1
U 1 1 664DFCE7
P 750 1950
F 0 "J1" H 668 1625 50  0000 C CNN
F 1 "Conn_01x03" H 668 1716 50  0001 C CNN
F 2 "Connector_Phoenix_MC_HighVoltage:PhoenixContact_MCV_1,5_3-G-5.08_1x03_P5.08mm_Vertical" H 750 1950 50  0001 C CNN
F 3 "~" H 750 1950 50  0001 C CNN
	1    750  1950
	-1   0    0    1   
$EndComp
$Comp
L Device:Fuse F1
U 1 1 664E2550
P 1400 1850
F 0 "F1" V 1203 1850 50  0000 C CNN
F 1 "Fusible 500mA" V 1294 1850 50  0000 C CNN
F 2 "0154004:FUSE_0154004.DR" V 1330 1850 50  0001 C CNN
F 3 "~" H 1400 1850 50  0001 C CNN
	1    1400 1850
	0    1    1    0   
$EndComp
$Comp
L Device:Fuse F2
U 1 1 664E2E61
P 1400 2050
F 0 "F2" V 1600 2000 50  0000 C CNN
F 1 "Fusible 500mA" V 1500 2050 50  0000 C CNN
F 2 "0154004:FUSE_0154004.DR" V 1330 2050 50  0001 C CNN
F 3 "~" H 1400 2050 50  0001 C CNN
	1    1400 2050
	0    1    1    0   
$EndComp
$Comp
L power:GND #PWR01
U 1 1 664E3424
P 1100 2350
F 0 "#PWR01" H 1100 2100 50  0001 C CNN
F 1 "GND" H 1105 2177 50  0000 C CNN
F 2 "" H 1100 2350 50  0001 C CNN
F 3 "" H 1100 2350 50  0001 C CNN
	1    1100 2350
	1    0    0    -1  
$EndComp
Wire Wire Line
	1100 2350 1100 1950
Wire Wire Line
	1100 1950 950  1950
Wire Wire Line
	1250 1850 950  1850
Wire Wire Line
	1250 2050 950  2050
Wire Wire Line
	1550 1850 1650 1850
Wire Wire Line
	1850 1850 1850 1700
Wire Wire Line
	2300 1700 2300 2050
Wire Wire Line
	2300 2050 1550 2050
Connection ~ 1850 1850
Connection ~ 2300 2050
Text GLabel 2600 1100 1    50   Input ~ 0
V+_brute
Text GLabel 2600 2800 3    50   Input ~ 0
V-nonfiltré
Wire Wire Line
	2600 1300 2600 1100
Wire Wire Line
	2600 2600 2600 2800
$Comp
L Connector_Generic:Conn_01x03 J2
U 1 1 664EAEBD
P 2850 700
F 0 "J2" V 2814 512 50  0000 R CNN
F 1 "Conn_01x03" V 2723 512 50  0001 R CNN
F 2 "Connector_Molex:Molex_KK-396_A-41791-0003_1x03_P3.96mm_Vertical" H 2850 700 50  0001 C CNN
F 3 "~" H 2850 700 50  0001 C CNN
	1    2850 700 
	0    -1   -1   0   
$EndComp
Wire Wire Line
	2750 1300 2600 1300
Connection ~ 2600 1300
Wire Wire Line
	2750 1300 2750 900 
Connection ~ 2600 2600
$Comp
L power:GND #PWR02
U 1 1 664ECD70
P 2950 1050
F 0 "#PWR02" H 2950 800 50  0001 C CNN
F 1 "GND" H 2955 877 50  0000 C CNN
F 2 "" H 2950 1050 50  0001 C CNN
F 3 "" H 2950 1050 50  0001 C CNN
	1    2950 1050
	1    0    0    -1  
$EndComp
$Comp
L Switch:SW_DIP_x04 SW4
U 1 1 664EE324
P 3700 3350
F 0 "SW4" V 3700 3700 50  0000 L CNN
F 1 "SW_DIP_x04" V 3745 3680 50  0001 L CNN
F 2 "Button_Switch_THT:SW_DIP_SPSTx04_Piano_10.8x11.72mm_W7.62mm_P2.54mm" H 3700 3350 50  0001 C CNN
F 3 "~" H 3700 3350 50  0001 C CNN
	1    3700 3350
	0    1    1    0   
$EndComp
Connection ~ 2750 1300
$Comp
L Device:CP C9
U 1 1 664F1CC5
P 4200 1450
F 0 "C9" H 4250 1550 50  0000 L CNN
F 1 "100µF" H 4050 1350 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D14.0mm_P5.00mm" H 4238 1300 50  0001 C CNN
F 3 "~" H 4200 1450 50  0001 C CNN
	1    4200 1450
	1    0    0    -1  
$EndComp
$Comp
L Device:CP C6
U 1 1 664F1061
P 3900 1450
F 0 "C6" H 3950 1550 50  0000 L CNN
F 1 "10µF" H 3750 1350 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D14.0mm_P5.00mm" H 3938 1300 50  0001 C CNN
F 3 "~" H 3900 1450 50  0001 C CNN
	1    3900 1450
	1    0    0    -1  
$EndComp
$Comp
L Device:CP C3
U 1 1 664F00EF
P 3600 1450
F 0 "C3" H 3400 1450 50  0000 L CNN
F 1 "1µF" H 3450 1350 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D14.0mm_P5.00mm" H 3638 1300 50  0001 C CNN
F 3 "~" H 3600 1450 50  0001 C CNN
	1    3600 1450
	1    0    0    -1  
$EndComp
$Comp
L Switch:SW_DIP_x04 SW3
U 1 1 664ED5BF
P 3700 2050
F 0 "SW3" V 3700 2400 50  0000 L CNN
F 1 "SW_DIP_x04" V 3745 2380 50  0001 L CNN
F 2 "Button_Switch_THT:SW_DIP_SPSTx04_Piano_10.8x11.72mm_W7.62mm_P2.54mm" H 3700 2050 50  0001 C CNN
F 3 "~" H 3700 2050 50  0001 C CNN
	1    3700 2050
	0    1    1    0   
$EndComp
$Comp
L Device:CP C10
U 1 1 664F68F9
P 4200 2750
F 0 "C10" H 4250 2850 50  0000 L CNN
F 1 "100µF" H 4050 2650 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D14.0mm_P5.00mm" H 4238 2600 50  0001 C CNN
F 3 "~" H 4200 2750 50  0001 C CNN
	1    4200 2750
	-1   0    0    1   
$EndComp
$Comp
L Device:CP C7
U 1 1 664F68FF
P 3900 2750
F 0 "C7" H 3950 2850 50  0000 L CNN
F 1 "10µF" H 3750 2650 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D14.0mm_P5.00mm" H 3938 2600 50  0001 C CNN
F 3 "~" H 3900 2750 50  0001 C CNN
	1    3900 2750
	-1   0    0    1   
$EndComp
$Comp
L Device:CP C4
U 1 1 664F6905
P 3600 2750
F 0 "C4" H 3400 2750 50  0000 L CNN
F 1 "1µF" H 3450 2650 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D14.0mm_P5.00mm" H 3638 2600 50  0001 C CNN
F 3 "~" H 3600 2750 50  0001 C CNN
	1    3600 2750
	-1   0    0    1   
$EndComp
$Comp
L Device:CP C11
U 1 1 664F9FAF
P 4500 1450
F 0 "C11" H 4550 1550 50  0000 L CNN
F 1 "1000µF" H 4350 1350 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D14.0mm_P5.00mm" H 4538 1300 50  0001 C CNN
F 3 "~" H 4500 1450 50  0001 C CNN
	1    4500 1450
	1    0    0    -1  
$EndComp
Wire Wire Line
	2750 1300 3600 1300
Connection ~ 3600 1300
Wire Wire Line
	3600 1300 3900 1300
Connection ~ 3900 1300
Wire Wire Line
	3900 1300 4200 1300
Connection ~ 4200 1300
Wire Wire Line
	4200 1300 4500 1300
Wire Wire Line
	3900 1750 4500 1750
Wire Wire Line
	4500 1750 4500 1600
Wire Wire Line
	3800 1750 3800 1700
Wire Wire Line
	3800 1700 4200 1700
Wire Wire Line
	4200 1700 4200 1600
Wire Wire Line
	3700 1750 3700 1650
Wire Wire Line
	3700 1650 3900 1650
Wire Wire Line
	3900 1650 3900 1600
Wire Wire Line
	3600 1750 3600 1600
Wire Wire Line
	3600 2350 3700 2350
Connection ~ 3700 2350
Wire Wire Line
	3700 2350 3800 2350
Connection ~ 3800 2350
Wire Wire Line
	3800 2350 3900 2350
Wire Wire Line
	3900 2350 4100 2350
Connection ~ 3900 2350
$Comp
L power:GND #PWR04
U 1 1 664FEF28
P 4100 2350
F 0 "#PWR04" H 4100 2100 50  0001 C CNN
F 1 "GND" V 4105 2222 50  0000 R CNN
F 2 "" H 4100 2350 50  0001 C CNN
F 3 "" H 4100 2350 50  0001 C CNN
	1    4100 2350
	0    -1   -1   0   
$EndComp
$Comp
L Device:CP C12
U 1 1 6650046B
P 4500 2750
F 0 "C12" H 4550 2850 50  0000 L CNN
F 1 "1000µF" H 4350 2650 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D14.0mm_P5.00mm" H 4538 2600 50  0001 C CNN
F 3 "~" H 4500 2750 50  0001 C CNN
	1    4500 2750
	-1   0    0    1   
$EndComp
Wire Wire Line
	3900 3050 4500 3050
Wire Wire Line
	3800 3050 3800 3000
Wire Wire Line
	3800 3000 4200 3000
Wire Wire Line
	3700 3050 3700 2950
Wire Wire Line
	3600 3050 3600 2900
Wire Wire Line
	3700 2950 3900 2950
Wire Wire Line
	3900 2950 3900 2900
Wire Wire Line
	4200 3000 4200 2900
Wire Wire Line
	4500 3050 4500 2900
Wire Wire Line
	3600 3650 3700 3650
Connection ~ 3700 3650
Wire Wire Line
	3700 3650 3800 3650
Connection ~ 3800 3650
Wire Wire Line
	3800 3650 3900 3650
Wire Wire Line
	4100 3650 3900 3650
Connection ~ 3900 3650
$Comp
L power:GND #PWR05
U 1 1 66513708
P 4100 3650
F 0 "#PWR05" H 4100 3400 50  0001 C CNN
F 1 "GND" V 4105 3522 50  0000 R CNN
F 2 "" H 4100 3650 50  0001 C CNN
F 3 "" H 4100 3650 50  0001 C CNN
	1    4100 3650
	0    -1   -1   0   
$EndComp
Text Notes 3150 850  0    50   ~ 0
Output\nfiltered /unfiltered\nf(C)
$Comp
L Regulator_Linear:L7812 U1
U 1 1 665145B0
P 5100 1300
F 0 "U1" H 5250 1050 50  0000 C CNN
F 1 "L7812" H 4850 1050 50  0000 C CNN
F 2 "Package_TO_SOT_THT:TO-220-3_Horizontal_TabDown" H 5125 1150 50  0001 L CIN
F 3 "http://www.st.com/content/ccc/resource/technical/document/datasheet/41/4f/b3/b0/12/d4/47/88/CD00000444.pdf/files/CD00000444.pdf/jcr:content/translations/en.CD00000444.pdf" H 5100 1250 50  0001 C CNN
	1    5100 1300
	1    0    0    -1  
$EndComp
Wire Wire Line
	4800 1300 4750 1300
Connection ~ 4500 1300
$Comp
L Regulator_Linear:L7912 U2
U 1 1 66517661
P 5100 2600
F 0 "U2" H 5300 2850 50  0000 C CNN
F 1 "L7912" H 4850 2850 50  0000 C CNN
F 2 "Package_TO_SOT_THT:TO-220-3_Horizontal_TabDown" H 5100 2400 50  0001 C CIN
F 3 "http://www.st.com/content/ccc/resource/technical/document/datasheet/c9/16/86/41/c7/2b/45/f2/CD00000450.pdf/files/CD00000450.pdf/jcr:content/translations/en.CD00000450.pdf" H 5100 2600 50  0001 C CNN
	1    5100 2600
	1    0    0    -1  
$EndComp
Wire Wire Line
	4800 2600 4750 2600
$Comp
L power:GND #PWR07
U 1 1 66519847
P 4950 1950
F 0 "#PWR07" H 4950 1700 50  0001 C CNN
F 1 "GND" V 4955 1822 50  0000 R CNN
F 2 "" H 4950 1950 50  0001 C CNN
F 3 "" H 4950 1950 50  0001 C CNN
	1    4950 1950
	0    1    1    0   
$EndComp
Wire Wire Line
	5100 1600 5100 1950
Wire Wire Line
	4950 1950 5100 1950
Connection ~ 5100 1950
Wire Wire Line
	5100 1950 5100 2300
Wire Wire Line
	4750 900  4750 1300
Connection ~ 4750 1300
Wire Wire Line
	4750 1300 4500 1300
Wire Wire Line
	5300 900  5500 900 
Wire Wire Line
	5500 900  5500 1300
Wire Wire Line
	5500 1300 5400 1300
Wire Wire Line
	4750 2600 4750 3050
Connection ~ 4750 2600
Wire Wire Line
	5300 3050 5500 3050
Wire Wire Line
	5500 3050 5500 2600
Wire Wire Line
	5500 2600 5400 2600
$Comp
L Device:CP C13
U 1 1 66521E20
P 5750 1450
F 0 "C13" H 5500 1350 50  0000 L CNN
F 1 "10µF" H 5850 1350 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D14.0mm_P5.00mm" H 5788 1300 50  0001 C CNN
F 3 "~" H 5750 1450 50  0001 C CNN
	1    5750 1450
	1    0    0    -1  
$EndComp
$Comp
L Device:CP C14
U 1 1 665221EA
P 5750 2750
F 0 "C14" H 5800 2850 50  0000 L CNN
F 1 "10µF" H 5450 2850 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D14.0mm_P5.00mm" H 5788 2600 50  0001 C CNN
F 3 "~" H 5750 2750 50  0001 C CNN
	1    5750 2750
	-1   0    0    1   
$EndComp
$Comp
L power:GND #PWR08
U 1 1 66522D8A
P 5750 1700
F 0 "#PWR08" H 5750 1450 50  0001 C CNN
F 1 "GND" H 5755 1527 50  0000 C CNN
F 2 "" H 5750 1700 50  0001 C CNN
F 3 "" H 5750 1700 50  0001 C CNN
	1    5750 1700
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR09
U 1 1 66523271
P 5750 3000
F 0 "#PWR09" H 5750 2750 50  0001 C CNN
F 1 "GND" H 5755 2827 50  0000 C CNN
F 2 "" H 5750 3000 50  0001 C CNN
F 3 "" H 5750 3000 50  0001 C CNN
	1    5750 3000
	1    0    0    -1  
$EndComp
Wire Wire Line
	5750 2900 5750 3000
Wire Wire Line
	5750 1600 5750 1700
Wire Wire Line
	5750 1300 5500 1300
Connection ~ 5500 1300
Wire Wire Line
	5750 2600 5500 2600
Connection ~ 5500 2600
$Comp
L Connector_Generic:Conn_01x03 J4
U 1 1 66528B4B
P 6150 750
F 0 "J4" V 6114 562 50  0000 R CNN
F 1 "Conn_01x03" V 6250 1250 50  0001 R CNN
F 2 "Connector_Molex:Molex_KK-396_A-41791-0003_1x03_P3.96mm_Vertical" H 6150 750 50  0001 C CNN
F 3 "~" H 6150 750 50  0001 C CNN
	1    6150 750 
	0    -1   -1   0   
$EndComp
Text GLabel 5750 1200 1    50   Input ~ 0
V+régulée
Text GLabel 5750 2550 1    50   Input ~ 0
V-régulée
Wire Wire Line
	5750 1200 5750 1300
Connection ~ 5750 1300
Wire Wire Line
	5750 1300 6050 1300
Wire Wire Line
	6050 1300 6050 1000
Wire Wire Line
	5750 2600 5750 2550
Connection ~ 5750 2600
$Comp
L power:GND #PWR014
U 1 1 66532325
P 6700 1050
F 0 "#PWR014" H 6700 800 50  0001 C CNN
F 1 "GND" H 6705 877 50  0000 C CNN
F 2 "" H 6700 1050 50  0001 C CNN
F 3 "" H 6700 1050 50  0001 C CNN
	1    6700 1050
	0    -1   -1   0   
$EndComp
Text Notes 5850 650  0    50   ~ 0
Output DC +12V/-12V regulated\n
Wire Wire Line
	6050 1300 6650 1300
Connection ~ 6050 1300
$Comp
L power:+12V #PWR010
U 1 1 66537AEE
P 6650 1300
F 0 "#PWR010" H 6650 1150 50  0001 C CNN
F 1 "+12V" H 6800 1350 50  0000 C CNN
F 2 "" H 6650 1300 50  0001 C CNN
F 3 "" H 6650 1300 50  0001 C CNN
	1    6650 1300
	1    0    0    -1  
$EndComp
$Comp
L power:-12V #PWR012
U 1 1 665383F1
P 6650 2600
F 0 "#PWR012" H 6650 2700 50  0001 C CNN
F 1 "-12V" H 6665 2773 50  0000 C CNN
F 2 "" H 6650 2600 50  0001 C CNN
F 3 "" H 6650 2600 50  0001 C CNN
	1    6650 2600
	1    0    0    -1  
$EndComp
Text Notes 3300 3800 0    50   ~ 0
Filtering capacitor selection\n
Text Notes 3350 2500 0    50   ~ 0
Filtering capacitor selection
Text Notes 6450 2200 0    50   ~ 0
POWER On
Text Notes 5350 10200 0    50   ~ 0
Platine continue
Wire Wire Line
	1650 1850 1650 3800
Connection ~ 1650 1850
Wire Wire Line
	1650 1850 1850 1850
$Comp
L Switch:SW_DIP_x04 SW1
U 1 1 666C61B3
P 2800 4950
F 0 "SW1" V 2800 4500 50  0000 L CNN
F 1 "SW_DIP_x04" H 2600 4700 50  0001 L CNN
F 2 "Button_Switch_THT:SW_DIP_SPSTx04_Piano_10.8x11.72mm_W7.62mm_P2.54mm" H 2800 4950 50  0001 C CNN
F 3 "~" H 2800 4950 50  0001 C CNN
	1    2800 4950
	0    1    1    0   
$EndComp
$Comp
L Device:R R1
U 1 1 666DC929
P 2700 4450
F 0 "R1" H 2600 4600 50  0000 L CNN
F 1 "100K" V 2700 4350 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0414_L11.9mm_D4.5mm_P15.24mm_Horizontal" V 2630 4450 50  0001 C CNN
F 3 "~" H 2700 4450 50  0001 C CNN
	1    2700 4450
	1    0    0    -1  
$EndComp
$Comp
L Device:R R2
U 1 1 666DCF37
P 2800 4450
F 0 "R2" H 2700 4600 50  0000 L CNN
F 1 "10K" V 2800 4400 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0414_L11.9mm_D4.5mm_P15.24mm_Horizontal" V 2730 4450 50  0001 C CNN
F 3 "~" H 2800 4450 50  0001 C CNN
	1    2800 4450
	1    0    0    -1  
$EndComp
$Comp
L Device:R R3
U 1 1 666DD132
P 2900 4450
F 0 "R3" H 2800 4600 50  0000 L CNN
F 1 "1K" V 2900 4450 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0414_L11.9mm_D4.5mm_P15.24mm_Horizontal" V 2830 4450 50  0001 C CNN
F 3 "~" H 2900 4450 50  0001 C CNN
	1    2900 4450
	1    0    0    -1  
$EndComp
$Comp
L Device:R R4
U 1 1 666DD2B0
P 3000 4450
F 0 "R4" H 2900 4600 50  0000 L CNN
F 1 "100" V 3000 4400 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0414_L11.9mm_D4.5mm_P15.24mm_Horizontal" V 2930 4450 50  0001 C CNN
F 3 "~" H 3000 4450 50  0001 C CNN
	1    3000 4450
	1    0    0    -1  
$EndComp
Wire Wire Line
	2550 3900 2700 3900
Wire Wire Line
	2700 3900 2700 4300
Connection ~ 2700 3900
Wire Wire Line
	2700 3900 2800 3900
Wire Wire Line
	2700 4600 2700 4650
Wire Wire Line
	2800 4650 2800 4600
Wire Wire Line
	2900 4600 2900 4650
Wire Wire Line
	3000 4650 3000 4600
Wire Wire Line
	2800 4300 2800 3900
Connection ~ 2800 3900
Wire Wire Line
	2800 3900 2900 3900
Wire Wire Line
	2900 4300 2900 3900
Connection ~ 2900 3900
Wire Wire Line
	2900 3900 3000 3900
Wire Wire Line
	3000 4300 3000 3900
Connection ~ 3000 3900
$Comp
L Switch:SW_DIP_x04 SW2
U 1 1 6678985A
P 3450 4950
F 0 "SW2" V 3450 5300 50  0000 L CNN
F 1 "SW_DIP_x04" V 3495 5280 50  0001 L CNN
F 2 "Button_Switch_THT:SW_DIP_SPSTx04_Piano_10.8x11.72mm_W7.62mm_P2.54mm" H 3450 4950 50  0001 C CNN
F 3 "~" H 3450 4950 50  0001 C CNN
	1    3450 4950
	0    1    1    0   
$EndComp
Wire Wire Line
	3350 4650 3350 4500
Wire Wire Line
	3550 4500 3450 4500
Wire Wire Line
	3450 4500 3450 4650
Wire Wire Line
	3550 4650 3550 4550
Wire Wire Line
	3550 4550 3750 4550
Wire Wire Line
	3750 4550 3750 4500
Wire Wire Line
	3650 4650 3650 4600
Wire Wire Line
	3650 4600 3950 4600
Wire Wire Line
	3950 4600 3950 4500
Wire Wire Line
	3950 3900 3950 4200
Wire Wire Line
	3000 3900 3350 3900
Wire Wire Line
	3750 4200 3750 3900
Connection ~ 3750 3900
Wire Wire Line
	3750 3900 3950 3900
Wire Wire Line
	3550 4200 3550 3900
Connection ~ 3550 3900
Wire Wire Line
	3550 3900 3750 3900
Wire Wire Line
	3350 4200 3350 3900
Connection ~ 3350 3900
Wire Wire Line
	3350 3900 3550 3900
Wire Wire Line
	4300 3900 3950 3900
Connection ~ 3950 3900
Wire Wire Line
	4300 4000 4250 4000
Wire Wire Line
	4250 4000 4250 4300
$Comp
L power:GND #PWR06
U 1 1 66810446
P 4250 4300
F 0 "#PWR06" H 4250 4050 50  0001 C CNN
F 1 "GND" H 4255 4127 50  0000 C CNN
F 2 "" H 4250 4300 50  0001 C CNN
F 3 "" H 4250 4300 50  0001 C CNN
	1    4250 4300
	1    0    0    -1  
$EndComp
Text Notes 1400 4100 0    50   ~ 0
Half wave rectification
Text Notes 600  1500 0    50   ~ 0
Input\n2x12V RMS
Text Notes 4300 4150 0    50   ~ 0
Voltage output
$Comp
L Device:LED D8
U 1 1 66812856
P 6650 1450
F 0 "D8" V 6689 1332 50  0000 R CNN
F 1 "LED" V 6598 1332 50  0000 R CNN
F 2 "LED_SMD:LED_1812_4532Metric" H 6650 1450 50  0001 C CNN
F 3 "~" H 6650 1450 50  0001 C CNN
	1    6650 1450
	0    -1   -1   0   
$EndComp
$Comp
L Device:LED D9
U 1 1 66813A70
P 6650 2750
F 0 "D9" V 6597 2830 50  0000 L CNN
F 1 "LED" V 6688 2830 50  0000 L CNN
F 2 "LED_SMD:LED_1812_4532Metric" H 6650 2750 50  0001 C CNN
F 3 "~" H 6650 2750 50  0001 C CNN
	1    6650 2750
	0    1    1    0   
$EndComp
Connection ~ 6650 2600
Connection ~ 6650 1300
$Comp
L Device:R R5
U 1 1 66814A2A
P 6650 1750
F 0 "R5" H 6450 1750 50  0000 L CNN
F 1 "2.2K" V 6650 1650 50  0000 L CNN
F 2 "Resistor_SMD:R_1206_3216Metric_Pad1.42x1.75mm_HandSolder" V 6580 1750 50  0001 C CNN
F 3 "~" H 6650 1750 50  0001 C CNN
	1    6650 1750
	1    0    0    -1  
$EndComp
$Comp
L Device:R R6
U 1 1 66814FB8
P 6650 3050
F 0 "R6" H 6450 3050 50  0000 L CNN
F 1 "2.2K" V 6650 2950 50  0000 L CNN
F 2 "Resistor_SMD:R_1206_3216Metric_Pad1.42x1.75mm_HandSolder" V 6580 3050 50  0001 C CNN
F 3 "~" H 6650 3050 50  0001 C CNN
	1    6650 3050
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR011
U 1 1 6681532B
P 6650 1900
F 0 "#PWR011" H 6650 1650 50  0001 C CNN
F 1 "GND" H 6800 1850 50  0000 C CNN
F 2 "" H 6650 1900 50  0001 C CNN
F 3 "" H 6650 1900 50  0001 C CNN
	1    6650 1900
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR013
U 1 1 668156CA
P 6650 3200
F 0 "#PWR013" H 6650 2950 50  0001 C CNN
F 1 "GND" H 6655 3027 50  0000 C CNN
F 2 "" H 6650 3200 50  0001 C CNN
F 3 "" H 6650 3200 50  0001 C CNN
	1    6650 3200
	1    0    0    -1  
$EndComp
$Comp
L Connector_Generic:Conn_01x03 J5
U 1 1 665254F8
P 6600 750
F 0 "J5" V 6564 562 50  0000 R CNN
F 1 "Conn_01x03" V 6700 1250 50  0001 R CNN
F 2 "Connector_Molex:Molex_KK-396_A-41791-0003_1x03_P3.96mm_Vertical" H 6600 750 50  0001 C CNN
F 3 "~" H 6600 750 50  0001 C CNN
	1    6600 750 
	0    -1   -1   0   
$EndComp
Wire Wire Line
	6050 1000 6500 1000
Wire Wire Line
	6500 1000 6500 950 
Connection ~ 6050 1000
Wire Wire Line
	6050 1000 6050 950 
Wire Wire Line
	6700 950  6700 1050
Wire Wire Line
	6700 1050 6250 1050
Wire Wire Line
	6250 1050 6250 950 
Wire Wire Line
	6600 950  6600 1100
Wire Wire Line
	2600 2600 2850 2600
Wire Wire Line
	2950 1050 2950 900 
Wire Wire Line
	2850 900  2850 2600
Connection ~ 2850 2600
Wire Wire Line
	5750 2600 6150 2600
Wire Wire Line
	6150 950  6150 1100
Connection ~ 6150 2600
Wire Wire Line
	6150 2600 6650 2600
Wire Wire Line
	6600 1100 6150 1100
Connection ~ 6150 1100
Wire Wire Line
	6150 1100 6150 2600
Connection ~ 6700 1050
Text Notes 6000 650  0    50   ~ 0
\n
$Comp
L Connector_Generic:Conn_01x03 J3
U 1 1 667229A3
P 4500 3900
F 0 "J3" H 4550 4100 50  0000 R CNN
F 1 "Conn_01x03" V 4373 3712 50  0001 R CNN
F 2 "Connector_Molex:Molex_KK-396_A-41791-0003_1x03_P3.96mm_Vertical" H 4500 3900 50  0001 C CNN
F 3 "~" H 4500 3900 50  0001 C CNN
	1    4500 3900
	1    0    0    -1  
$EndComp
Wire Wire Line
	4300 3800 1650 3800
Connection ~ 1650 3800
Wire Wire Line
	1650 3800 1650 3900
$Comp
L Diode:1N4007 D3
U 1 1 6674AAAB
P 2300 1550
F 0 "D3" V 2254 1630 50  0000 L CNN
F 1 "1N4007" V 2345 1630 50  0000 L CNN
F 2 "Diode_THT:D_DO-41_SOD81_P12.70mm_Horizontal" H 2300 1375 50  0001 C CNN
F 3 "http://www.vishay.com/docs/88503/1n4001.pdf" H 2300 1550 50  0001 C CNN
	1    2300 1550
	0    1    1    0   
$EndComp
Wire Wire Line
	1850 1300 2300 1300
$Comp
L Diode:1N4007 D1
U 1 1 6674B31B
P 1850 1550
F 0 "D1" V 1804 1630 50  0000 L CNN
F 1 "1N4007" V 1895 1630 50  0000 L CNN
F 2 "Diode_THT:D_DO-41_SOD81_P12.70mm_Horizontal" H 1850 1375 50  0001 C CNN
F 3 "http://www.vishay.com/docs/88503/1n4001.pdf" H 1850 1550 50  0001 C CNN
	1    1850 1550
	0    1    1    0   
$EndComp
Wire Wire Line
	1850 2600 2300 2600
$Comp
L Diode:1N4007 D2
U 1 1 6674CF4C
P 1850 2450
F 0 "D2" V 1804 2530 50  0000 L CNN
F 1 "1N4007" V 1895 2530 50  0000 L CNN
F 2 "Diode_THT:D_DO-41_SOD81_P12.70mm_Horizontal" H 1850 2275 50  0001 C CNN
F 3 "http://www.vishay.com/docs/88503/1n4001.pdf" H 1850 2450 50  0001 C CNN
	1    1850 2450
	0    1    1    0   
$EndComp
$Comp
L Diode:1N4007 D4
U 1 1 6674D779
P 2300 2450
F 0 "D4" V 2254 2530 50  0000 L CNN
F 1 "1N4007" V 2345 2530 50  0000 L CNN
F 2 "Diode_THT:D_DO-41_SOD81_P12.70mm_Horizontal" H 2300 2275 50  0001 C CNN
F 3 "http://www.vishay.com/docs/88503/1n4001.pdf" H 2300 2450 50  0001 C CNN
	1    2300 2450
	0    1    1    0   
$EndComp
Connection ~ 2300 2600
Wire Wire Line
	2300 2600 2600 2600
Wire Wire Line
	1850 1300 1850 1400
Wire Wire Line
	2300 1400 2300 1300
Connection ~ 2300 1300
Wire Wire Line
	2300 1300 2600 1300
Wire Wire Line
	1850 1850 1850 2300
Wire Wire Line
	2300 2050 2300 2300
$Comp
L Diode:1N4007 D5
U 1 1 6677965C
P 2400 3900
F 0 "D5" H 2400 3683 50  0000 C CNN
F 1 "1N4007" H 2400 3774 50  0000 C CNN
F 2 "Diode_THT:D_DO-41_SOD81_P12.70mm_Horizontal" H 2400 3725 50  0001 C CNN
F 3 "http://www.vishay.com/docs/88503/1n4001.pdf" H 2400 3900 50  0001 C CNN
	1    2400 3900
	-1   0    0    1   
$EndComp
Wire Wire Line
	1650 3900 2250 3900
$Comp
L Diode:1N4007 D6
U 1 1 66785821
P 5150 900
F 0 "D6" H 5150 1117 50  0000 C CNN
F 1 "1N4007" H 5150 1026 50  0000 C CNN
F 2 "Diode_THT:D_DO-41_SOD81_P12.70mm_Horizontal" H 5150 725 50  0001 C CNN
F 3 "http://www.vishay.com/docs/88503/1n4001.pdf" H 5150 900 50  0001 C CNN
	1    5150 900 
	1    0    0    -1  
$EndComp
Wire Wire Line
	4750 900  5000 900 
$Comp
L Diode:1N4007 D7
U 1 1 667916E0
P 5150 3050
F 0 "D7" H 5150 2833 50  0000 C CNN
F 1 "1N4007" H 5150 2924 50  0000 C CNN
F 2 "Diode_THT:D_DO-41_SOD81_P12.70mm_Horizontal" H 5150 2875 50  0001 C CNN
F 3 "http://www.vishay.com/docs/88503/1n4001.pdf" H 5150 3050 50  0001 C CNN
	1    5150 3050
	-1   0    0    1   
$EndComp
Wire Wire Line
	4750 3050 5000 3050
Connection ~ 5400 3900
Wire Wire Line
	5500 3900 5400 3900
$Comp
L Diode:1N4007 D11
U 1 1 6679D814
P 5650 3900
F 0 "D11" H 5650 3683 50  0000 C CNN
F 1 "1N4007" H 5650 3774 50  0000 C CNN
F 2 "Diode_THT:D_DO-41_SOD81_P12.70mm_Horizontal" H 5650 3725 50  0001 C CNN
F 3 "http://www.vishay.com/docs/88503/1n4001.pdf" H 5650 3900 50  0001 C CNN
	1    5650 3900
	-1   0    0    1   
$EndComp
Text Notes 5300 4450 0    50   ~ 0
Diode : I=f(U)
Wire Wire Line
	6450 3900 6450 4000
$Comp
L power:GND #PWR020
U 1 1 66652E16
P 6450 4000
F 0 "#PWR020" H 6450 3750 50  0001 C CNN
F 1 "GND" H 6455 3827 50  0000 C CNN
F 2 "" H 6450 4000 50  0001 C CNN
F 3 "" H 6450 4000 50  0001 C CNN
	1    6450 4000
	1    0    0    -1  
$EndComp
Connection ~ 6100 3900
Wire Wire Line
	6100 3800 6450 3800
Wire Wire Line
	6100 3900 6100 3800
Wire Wire Line
	5400 3700 6450 3700
Wire Wire Line
	5400 3900 5400 3700
Wire Wire Line
	5150 3750 5150 3600
$Comp
L power:+12V #PWR015
U 1 1 66629CA4
P 5150 3600
F 0 "#PWR015" H 5150 3450 50  0001 C CNN
F 1 "+12V" H 5300 3650 50  0000 C CNN
F 2 "" H 5150 3600 50  0001 C CNN
F 3 "" H 5150 3600 50  0001 C CNN
	1    5150 3600
	1    0    0    -1  
$EndComp
Wire Wire Line
	6100 4000 6100 3900
Wire Wire Line
	6100 4350 6100 4300
$Comp
L power:GND #PWR019
U 1 1 665E6BA2
P 6100 4350
F 0 "#PWR019" H 6100 4100 50  0001 C CNN
F 1 "GND" H 6105 4177 50  0000 C CNN
F 2 "" H 6100 4350 50  0001 C CNN
F 3 "" H 6100 4350 50  0001 C CNN
	1    6100 4350
	1    0    0    -1  
$EndComp
Wire Wire Line
	5300 3900 5400 3900
Wire Wire Line
	5150 4050 5150 4150
Wire Wire Line
	6100 3900 5800 3900
$Comp
L Device:R_POT RV1
U 1 1 66582ABD
P 5150 3900
F 0 "RV1" H 5081 3946 50  0000 R CNN
F 1 "R_POT" H 5081 3855 50  0000 R CNN
F 2 "Potentiometer_THT:Potentiometer_Alps_RK09L_Single_Vertical" H 5150 3900 50  0001 C CNN
F 3 "~" H 5150 3900 50  0001 C CNN
	1    5150 3900
	1    0    0    -1  
$EndComp
$Comp
L Device:R R11
U 1 1 665809EE
P 6100 4150
F 0 "R11" H 6250 4200 50  0000 L CNN
F 1 "220" V 6100 4050 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0414_L11.9mm_D4.5mm_P15.24mm_Horizontal" V 6030 4150 50  0001 C CNN
F 3 "~" H 6100 4150 50  0001 C CNN
	1    6100 4150
	-1   0    0    1   
$EndComp
$Comp
L Connector_Generic:Conn_01x03 J6
U 1 1 6650D4CE
P 6650 3800
F 0 "J6" H 6700 4050 50  0000 R CNN
F 1 "Conn_01x03" V 6750 3800 50  0001 R CNN
F 2 "Connector_Molex:Molex_KK-396_A-41791-0003_1x03_P3.96mm_Vertical" H 6650 3800 50  0001 C CNN
F 3 "~" H 6650 3800 50  0001 C CNN
	1    6650 3800
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR016
U 1 1 6658B4D3
P 5150 4150
F 0 "#PWR016" H 5150 3900 50  0001 C CNN
F 1 "GND" H 5155 3977 50  0000 C CNN
F 2 "" H 5150 4150 50  0001 C CNN
F 3 "" H 5150 4150 50  0001 C CNN
	1    5150 4150
	1    0    0    -1  
$EndComp
$Comp
L Reference_Voltage:MCP1541-TO U3
U 1 1 66720E08
P 2800 6500
F 0 "U3" H 2670 6546 50  0000 R CNN
F 1 "4.096V" H 2670 6455 50  0000 R CNN
F 2 "Package_TO_SOT_THT:TO-92_Inline" H 2850 6250 50  0001 L CIN
F 3 "http://ww1.microchip.com/downloads/en/devicedoc/21653b.pdf" H 2800 6500 50  0001 C CIN
	1    2800 6500
	1    0    0    -1  
$EndComp
Connection ~ 3000 5300
Connection ~ 3200 5300
Wire Wire Line
	3200 5300 3000 5300
Wire Wire Line
	3200 5300 3350 5300
Wire Wire Line
	3200 5350 3200 5300
Wire Wire Line
	3550 5300 3650 5300
Connection ~ 3550 5300
Wire Wire Line
	3550 5300 3550 5250
Wire Wire Line
	3450 5300 3550 5300
Connection ~ 3450 5300
Wire Wire Line
	3450 5300 3450 5250
Wire Wire Line
	3350 5300 3450 5300
Connection ~ 3350 5300
Wire Wire Line
	3350 5300 3350 5250
Wire Wire Line
	3650 5250 3650 5300
Wire Wire Line
	1950 7450 2000 7450
Connection ~ 1950 7450
$Comp
L power:GND #PWR018
U 1 1 6667B9B9
P 1950 7450
F 0 "#PWR018" H 1950 7200 50  0001 C CNN
F 1 "GND" H 1800 7450 50  0000 C CNN
F 2 "" H 1950 7450 50  0001 C CNN
F 3 "" H 1950 7450 50  0001 C CNN
	1    1950 7450
	1    0    0    -1  
$EndComp
Connection ~ 3750 6150
Wire Wire Line
	4100 6150 4100 5800
Wire Wire Line
	3750 6150 4100 6150
$Comp
L Connector_Generic:Conn_01x03 J7
U 1 1 66660852
P 4100 5600
F 0 "J7" V 4064 5412 50  0000 R CNN
F 1 "Conn_01x03" V 3973 5412 50  0001 R CNN
F 2 "Connector_Molex:Molex_KK-396_A-41791-0003_1x03_P3.96mm_Vertical" H 4100 5600 50  0001 C CNN
F 3 "~" H 4100 5600 50  0001 C CNN
	1    4100 5600
	0    -1   -1   0   
$EndComp
Wire Wire Line
	1900 7450 1950 7450
Connection ~ 1400 4350
$Comp
L power:GND #PWR021
U 1 1 665809CE
P 2800 7100
F 0 "#PWR021" H 2800 6850 50  0001 C CNN
F 1 "GND" H 2805 6927 50  0000 C CNN
F 2 "" H 2800 7100 50  0001 C CNN
F 3 "" H 2800 7100 50  0001 C CNN
	1    2800 7100
	1    0    0    -1  
$EndComp
Wire Wire Line
	2800 6800 2800 6950
Connection ~ 3750 5800
Wire Wire Line
	3200 6500 3350 6500
Wire Wire Line
	2150 5800 1900 5800
Connection ~ 2150 5800
Wire Wire Line
	2150 5900 2150 5800
Wire Wire Line
	2200 5900 2150 5900
Connection ~ 1900 5800
Wire Wire Line
	2200 5800 2150 5800
Wire Wire Line
	1900 5800 1900 6250
$Comp
L Switch:SW_DIP_x02 SW7
U 1 1 664FAF8B
P 2500 5800
F 0 "SW7" H 2450 5650 50  0000 L CNN
F 1 "SW_DIP_x02" H 2200 5600 50  0001 L CNN
F 2 "Button_Switch_THT:SW_DIP_SPSTx02_Piano_10.8x6.64mm_W7.62mm_P2.54mm" H 2500 5800 50  0001 C CNN
F 3 "~" H 2500 5800 50  0001 C CNN
	1    2500 5800
	-1   0    0    1   
$EndComp
$Comp
L power:GND #PWR03
U 1 1 667804C4
P 3200 5350
F 0 "#PWR03" H 3200 5100 50  0001 C CNN
F 1 "GND" H 3450 5250 50  0000 R CNN
F 2 "" H 3200 5350 50  0001 C CNN
F 3 "" H 3200 5350 50  0001 C CNN
	1    3200 5350
	1    0    0    -1  
$EndComp
Wire Wire Line
	2800 5300 2900 5300
Connection ~ 2800 5300
Wire Wire Line
	2800 5250 2800 5300
Wire Wire Line
	2900 5300 3000 5300
Connection ~ 2900 5300
Wire Wire Line
	2900 5250 2900 5300
Wire Wire Line
	3000 5300 3000 5250
Wire Wire Line
	2700 5300 2800 5300
Wire Wire Line
	2700 5250 2700 5300
$Comp
L Device:R R10
U 1 1 66541DB7
P 1700 4700
F 0 "R10" H 1750 4700 50  0000 L CNN
F 1 "4.7k" V 1700 4600 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0414_L11.9mm_D4.5mm_P15.24mm_Horizontal" V 1630 4700 50  0001 C CNN
F 3 "~" H 1700 4700 50  0001 C CNN
	1    1700 4700
	1    0    0    -1  
$EndComp
$Comp
L Device:D_Zener D10
U 1 1 66556ECA
P 1400 6150
F 0 "D10" V 1450 5900 50  0000 L CNN
F 1 "D_Zener_9.1V/1W" V 1550 5450 50  0000 L CNN
F 2 "Diode_THT:D_DO-41_SOD81_P12.70mm_Horizontal" H 1400 6150 50  0001 C CNN
F 3 "~" H 1400 6150 50  0001 C CNN
	1    1400 6150
	0    1    1    0   
$EndComp
$Comp
L power:GND #PWR017
U 1 1 665576F9
P 1400 6300
F 0 "#PWR017" H 1400 6050 50  0001 C CNN
F 1 "GND" H 1405 6127 50  0000 C CNN
F 2 "" H 1400 6300 50  0001 C CNN
F 3 "" H 1400 6300 50  0001 C CNN
	1    1400 6300
	1    0    0    -1  
$EndComp
Text Notes 650  4950 0    50   ~ 0
Selection of\nprotective resistor
Text Notes 3250 7350 0    50   ~ 0
 Zener regulation
Wire Wire Line
	2000 7450 2000 7400
Wire Wire Line
	1900 7100 1900 7150
$Comp
L Device:CP C16
U 1 1 665822C2
P 2000 7250
F 0 "C16" H 1700 7250 50  0000 L CNN
F 1 "100µF" H 2100 7250 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D10.0mm_P5.00mm" H 2038 7100 50  0001 C CNN
F 3 "~" H 2000 7250 50  0001 C CNN
	1    2000 7250
	1    0    0    -1  
$EndComp
$Comp
L Device:CP C15
U 1 1 66581D13
P 1900 7000
F 0 "C15" H 1600 7050 50  0000 L CNN
F 1 "1µF" H 2050 7050 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D10.0mm_P5.00mm" H 1938 6850 50  0001 C CNN
F 3 "~" H 1900 7000 50  0001 C CNN
	1    1900 7000
	1    0    0    -1  
$EndComp
Connection ~ 1900 6250
Wire Wire Line
	2000 6250 1900 6250
Wire Wire Line
	1700 5800 1900 5800
$Comp
L Switch:SW_DIP_x02 SW6
U 1 1 6657A6A6
P 1900 6550
F 0 "SW6" V 1900 6800 50  0000 L CNN
F 1 "SW_DIP_x02" H 1700 6350 50  0001 L CNN
F 2 "Button_Switch_THT:SW_DIP_SPSTx02_Piano_10.8x6.64mm_W7.62mm_P2.54mm" H 1900 6550 50  0001 C CNN
F 3 "~" H 1900 6550 50  0001 C CNN
	1    1900 6550
	0    1    1    0   
$EndComp
Text Notes 3800 5450 0    50   ~ 0
Voltage/current/GND
$Comp
L power:GND #PWR023
U 1 1 66575AEE
P 4200 5900
F 0 "#PWR023" H 4200 5650 50  0001 C CNN
F 1 "GND" H 4205 5727 50  0000 C CNN
F 2 "" H 4200 5900 50  0001 C CNN
F 3 "" H 4200 5900 50  0001 C CNN
	1    4200 5900
	1    0    0    -1  
$EndComp
Wire Wire Line
	4200 5800 4200 5900
Connection ~ 3900 5800
Wire Wire Line
	4000 5800 3900 5800
Wire Wire Line
	3750 6450 3750 6500
Wire Wire Line
	3750 6100 3750 6150
$Comp
L power:GND #PWR022
U 1 1 665633D0
P 3750 6500
F 0 "#PWR022" H 3750 6250 50  0001 C CNN
F 1 "GND" H 3755 6327 50  0000 C CNN
F 2 "" H 3750 6500 50  0001 C CNN
F 3 "" H 3750 6500 50  0001 C CNN
	1    3750 6500
	1    0    0    -1  
$EndComp
$Comp
L Device:R R12
U 1 1 66562FB7
P 3750 6300
F 0 "R12" H 3550 6300 50  0000 L CNN
F 1 "220" V 3750 6250 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0414_L11.9mm_D4.5mm_P15.24mm_Horizontal" V 3680 6300 50  0001 C CNN
F 3 "~" H 3750 6300 50  0001 C CNN
	1    3750 6300
	1    0    0    -1  
$EndComp
Wire Wire Line
	3900 5800 3900 5950
Wire Wire Line
	3750 5800 3900 5800
Connection ~ 1700 5800
$Comp
L Device:R_POT RV2
U 1 1 6655D35D
P 3750 5950
F 0 "RV2" H 3681 5996 50  0000 R CNN
F 1 "Pot=1K" H 3681 5905 50  0000 R CNN
F 2 "Potentiometer_THT:Potentiometer_Alps_RK09L_Single_Vertical" H 3750 5950 50  0001 C CNN
F 3 "~" H 3750 5950 50  0001 C CNN
	1    3750 5950
	1    0    0    -1  
$EndComp
Wire Wire Line
	1100 4350 1000 4350
Text GLabel 1000 4350 0    50   Input ~ 0
V+_brute
Connection ~ 1400 5800
Wire Wire Line
	1400 5800 1400 6000
Wire Wire Line
	1600 5800 1700 5800
Connection ~ 1600 5800
Wire Wire Line
	1500 5800 1600 5800
Connection ~ 1500 5800
Wire Wire Line
	1400 5800 1500 5800
Wire Wire Line
	1400 4350 1500 4350
Wire Wire Line
	1400 4550 1400 4350
Wire Wire Line
	1500 4350 1600 4350
Connection ~ 1500 4350
Wire Wire Line
	1500 4550 1500 4350
Wire Wire Line
	1600 4350 1700 4350
Connection ~ 1600 4350
Wire Wire Line
	1600 4550 1600 4350
Wire Wire Line
	1700 4350 1700 4550
$Comp
L Device:R R9
U 1 1 66541B0F
P 1600 4700
F 0 "R9" H 1550 4550 50  0000 L CNN
F 1 "680" V 1600 4600 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0414_L11.9mm_D4.5mm_P15.24mm_Horizontal" V 1530 4700 50  0001 C CNN
F 3 "~" H 1600 4700 50  0001 C CNN
	1    1600 4700
	1    0    0    -1  
$EndComp
$Comp
L Device:R R8
U 1 1 66541A2E
P 1500 4700
F 0 "R8" H 1450 4900 50  0000 L CNN
F 1 "330" V 1500 4600 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0414_L11.9mm_D4.5mm_P15.24mm_Horizontal" V 1430 4700 50  0001 C CNN
F 3 "~" H 1500 4700 50  0001 C CNN
	1    1500 4700
	1    0    0    -1  
$EndComp
$Comp
L Device:R R7
U 1 1 665413C7
P 1400 4700
F 0 "R7" H 1200 4700 50  0000 L CNN
F 1 "68" V 1400 4600 50  0000 L CNN
F 2 "Resistor_THT:R_Axial_DIN0414_L11.9mm_D4.5mm_P15.24mm_Horizontal" V 1330 4700 50  0001 C CNN
F 3 "~" H 1400 4700 50  0001 C CNN
	1    1400 4700
	1    0    0    -1  
$EndComp
$Comp
L Switch:SW_DIP_x04 SW5
U 1 1 6653B153
P 1500 5500
F 0 "SW5" V 1500 5850 50  0000 L CNN
F 1 "SW_DIP_x04" V 1545 5830 50  0001 L CNN
F 2 "Button_Switch_THT:SW_DIP_SPSTx04_Piano_10.8x11.72mm_W7.62mm_P2.54mm" H 1500 5500 50  0001 C CNN
F 3 "~" H 1500 5500 50  0001 C CNN
	1    1500 5500
	0    1    1    0   
$EndComp
$Comp
L Device:Fuse F3
U 1 1 66538F28
P 1250 4350
F 0 "F3" V 1053 4350 50  0000 C CNN
F 1 "Fusible 100mA" V 1144 4350 50  0000 C CNN
F 2 "0154004:FUSE_0154004.DR" V 1180 4350 50  0001 C CNN
F 3 "~" H 1250 4350 50  0001 C CNN
	1    1250 4350
	0    1    1    0   
$EndComp
Wire Wire Line
	2000 6850 2000 7100
Wire Wire Line
	1900 7150 1900 7450
Connection ~ 1900 7150
$Comp
L Device:CP Cx1
U 1 1 66DFE3BD
P 3350 6800
F 0 "Cx1" H 3150 6800 50  0000 L CNN
F 1 "1µF" H 3150 6950 50  0000 L CNN
F 2 "Capacitor_SMD:C_0805_2012Metric_Pad1.15x1.40mm_HandSolder" H 3388 6650 50  0001 C CNN
F 3 "~" H 3350 6800 50  0001 C CNN
	1    3350 6800
	1    0    0    -1  
$EndComp
Wire Wire Line
	3350 6650 3350 6500
Wire Wire Line
	3350 6950 2800 6950
Connection ~ 2800 6950
Wire Wire Line
	2800 6950 2800 7100
Wire Wire Line
	2800 5800 3350 5800
$Comp
L Switch:SW_DIP_x01 SW8
U 1 1 674A709E
P 3350 6100
F 0 "SW8" V 3304 6230 50  0000 L CNN
F 1 "SW_DIP_x01" V 3700 6150 50  0000 L CNN
F 2 "Button_Switch_THT:SW_DIP_SPSTx01_Slide_9.78x4.72mm_W7.62mm_P2.54mm" H 3350 6100 50  0001 C CNN
F 3 "~" H 3350 6100 50  0001 C CNN
	1    3350 6100
	0    -1   -1   0   
$EndComp
Wire Wire Line
	1400 4850 1400 5200
Wire Wire Line
	1500 4850 1500 5200
Wire Wire Line
	1600 4850 1600 5200
Wire Wire Line
	1700 4850 1700 5200
Wire Wire Line
	2800 6200 2800 5900
Connection ~ 3350 5800
Wire Wire Line
	3350 5800 3750 5800
Wire Wire Line
	3350 6400 3350 6500
Connection ~ 3350 6500
$Comp
L Device:CP C8
U 1 1 6679274F
P 3950 4350
F 0 "C8" H 4000 4450 50  0000 L CNN
F 1 "1000µF" H 3750 4150 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D14.0mm_P5.00mm" H 3988 4200 50  0001 C CNN
F 3 "~" H 3950 4350 50  0001 C CNN
	1    3950 4350
	1    0    0    -1  
$EndComp
$Comp
L Device:CP C5
U 1 1 6679273D
P 3750 4350
F 0 "C5" H 3800 4450 50  0000 L CNN
F 1 "100µF" H 3550 4250 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D14.0mm_P5.00mm" H 3788 4200 50  0001 C CNN
F 3 "~" H 3750 4350 50  0001 C CNN
	1    3750 4350
	1    0    0    -1  
$EndComp
$Comp
L Device:CP C2
U 1 1 66792743
P 3550 4350
F 0 "C2" H 3600 4450 50  0000 L CNN
F 1 "10µF" H 3350 4250 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D14.0mm_P5.00mm" H 3588 4200 50  0001 C CNN
F 3 "~" H 3550 4350 50  0001 C CNN
	1    3550 4350
	1    0    0    -1  
$EndComp
$Comp
L Device:CP C1
U 1 1 66792749
P 3350 4350
F 0 "C1" H 3150 4350 50  0000 L CNN
F 1 "1µF" H 3150 4500 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D14.0mm_P5.00mm" H 3388 4200 50  0001 C CNN
F 3 "~" H 3350 4350 50  0001 C CNN
	1    3350 4350
	1    0    0    -1  
$EndComp
Wire Wire Line
	2850 2600 3600 2600
Connection ~ 3600 2600
Wire Wire Line
	3600 2600 3900 2600
Connection ~ 3900 2600
Wire Wire Line
	3900 2600 4200 2600
Connection ~ 4200 2600
Wire Wire Line
	4200 2600 4500 2600
Connection ~ 4500 2600
Wire Wire Line
	4500 2600 4750 2600
Text Notes 2550 7600 0    50   ~ 0
Voltage \nreference\nMCP1541
Text Notes 6500 4300 0    50   ~ 0
Voltage/current/GND
$EndSCHEMATC
